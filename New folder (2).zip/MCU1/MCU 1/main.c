/*
 * F19_SPI_Driver.c
 *
 * Created: 4/24/2021 11:50:28 AM
 * Author : Ali
 */ 
#include "LCD.h"
#include "UART.h"
#include "SPI.h"
#define F_CPU 16000000
#include <util/delay.h>

int main(void)
{
	uint8 data_1 = 0;
	UART_Init();
	LCD_Init();
    uint8 tx_data = 1;
	uint8 rx_data = 0;
	
	/*Init LED*/
	DIO_SetPinDir(DIO_PORTC , DIO_PIN2 , DIO_PIN_OUTPUT);
	
	SPI_Master_Init();
	SPI_Master_InitTrans();
	_delay_ms(1000);
	
    while (1) 
    {
		rx_data = SPI_TranSiver(1);
		data_1 = UART_Rx();
		LCD_Clear();
		LCD_WriteChar(data_1);
		if(data_1)
		{
			LCD_Clear();
			LCD_WriteChar(data_1);
			rx_data = SPI_TranSiver(data_1);
			rx_data = 0;
		}
		
		_delay_ms(1000);
    }
}

